
class AdsVariable {

  static bool isPurchase = false;

  static String fullscreen_on_in_splash_screen = '0';
  static String freeUse = '40';

  static int in_appFlag = 0;
  static String in_app_continueAdsOnline = '1';

  static int home_Flag = 0;
  static String home_continueAdsOnline = '1';

  static int how_to_play_Flag = 0;
  static String how_to_play_continueAdsOnline = '1';

  static int roulette_Flag = 0;
  static String roulette_continueAdsOnline = '1';

  static String fullscreen_preload_high_adsId = '11';
  static String fullscreen_preload_normal_adsId = '11';
  static String fullscreen_splash_adsId_high = '11';
  static String fullscreen_splash_adsId_normal = '11';
  static String fullscreen_in_app_adsId = '11';
  static String fullscreen_home_adsId = '11';
  static String fullscreen_how_to_play_adsId = '11';
  static String fullscreen_roulette_adsId = '11';

  static String banner_chooser_screen = '11';
  static String banner_coin_fliiper_screen = '11';
  static String banner_homograft_screen = '11';
  static String banner_how_to_play_screen = '11';
  static String banner_ranking_screen = '11';
  static String banner_roulette_screen = '11';
  static String banner_spin_bottle_screen = '11';
  static String banner_dice_screen = '11';

  static String native_onboarding_small = "ca-app-pub-3940256099942544/2247696110";
  static String native_onboarding_big = "ca-app-pub-3940256099942544/2247696110";

  static String appopen = 'ca-app-pub-3940256099942544/9257395921';

  static String facebookId = "11";
  static String facebookToken = "11";

  static String nativeBGColor = "121212";
  static String btnBgColor_start = "92EBFF";
  static String btnBgColor_end = "92EBFF";
  static String btnTextColor = "000000";
  static String headerTextColor = "FFFFFF";
  static String bodyTextColor = "DDDDDD";
}

